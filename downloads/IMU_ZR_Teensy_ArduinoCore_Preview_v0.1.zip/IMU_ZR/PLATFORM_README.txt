BOZKURT ROBOTIK — Teensy 4.x integration preview

Base source: IMU_ZR Arduino 0.2.1 (bundled, unchanged core driver).
This archive is an adaptation example for Teensy 4.x, not evidence of new firmware validation.
Teensyduino 4.0 / 4.1, Wire library; compiled or physical Teensy hardware tests are NOT available.

Installation: Arduino IDE > Sketch > Include Library > Add .ZIP Library.
Alternatively install the enclosed IMU_ZR/ folder in Arduino libraries directory.
The sample is under IMU_ZR/examples/Port_Teensy/.
Do not install multiple copies of the IMU_ZR library at once.

Hardware: LSM6DSOXTR 0x6A/0x6B via I2C; MMC5603NJ disabled by default.
Sensor logic 3.3V; use level shifting if host pins are 5V. Keep CS at 3.3V for I2C.
Do not assume a fixed VIN voltage without checking the board datasheet and LDO input.

Known limitation: Only the six-axis path has hardware evidence on Arduino Mega;
magnetometer on the evaluated board did not acknowledge. 9-axis not validated.
FIFO, sensor fusion, calibrated orientation, flight safety uses not supported.
Other platform builds and board I2C setups require validation on actual hardware.

Original driver README and VALIDATION.md accompany this package.
