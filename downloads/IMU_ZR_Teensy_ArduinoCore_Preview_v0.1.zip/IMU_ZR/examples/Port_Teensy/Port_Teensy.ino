#include <IMU_ZR.h>
IMU_ZR imu;
bool initialized = false;
void setup() {
  Serial.begin(115200);
  const uint32_t start = millis();
  while (!Serial && (uint32_t)(millis() - start) < 3000) { delay(5); }
  Wire.begin(); // Teensy 4.0/4.1 default: SDA 18, SCL 19. Verify board pinout.
  Wire.setClock(400000);
  initialized = imu.begin(Wire); // 6-axis default, mag disabled
  if (!initialized) Serial.println(IMU_ZR::errorText(imu.lastError()));
}
void loop() {
  if (!initialized) { delay(1000); return; }
  IMU_ZR::ImuSample s;
  if (imu.readImu(s)) {
    Serial.print(s.timestampUs); Serial.print(',');
    Serial.print(s.acceleration.x, 3); Serial.print(',');
    Serial.print(s.acceleration.y, 3); Serial.print(',');
    Serial.print(s.acceleration.z, 3); Serial.print(',');
    Serial.print(s.angularRate.x, 5); Serial.print(',');
    Serial.print(s.angularRate.y, 5); Serial.print(',');
    Serial.println(s.angularRate.z, 5);
  } else if (imu.lastError() != IMU_ZR::Error::NotReady) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
  }
  delay(10);
}
