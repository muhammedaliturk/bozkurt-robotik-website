#include <IMU_ZR.h>
IMU_ZR imu;
bool initialized = false;
// Example for classic ESP32 DevKit: actual SDA/SCL pins vary by board.
constexpr int SDA_PIN = 21;
constexpr int SCL_PIN = 22;
void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);
  Wire.setClock(400000);
  initialized = imu.begin(Wire); // 6-axis default, mag disabled
  if (!initialized) Serial.println(IMU_ZR::errorText(imu.lastError()));
}
void loop() {
  if (!initialized) { delay(1000); return; }
  IMU_ZR::ImuSample s;
  if (imu.readImu(s)) {
    Serial.printf("%lu,%.4f,%.4f,%.4f,%.5f,%.5f,%.5f\n",
      (unsigned long)s.timestampUs,
      s.acceleration.x, s.acceleration.y, s.acceleration.z,
      s.angularRate.x, s.angularRate.y, s.angularRate.z);
  } else if (imu.lastError() != IMU_ZR::Error::NotReady) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
  }
  delay(10);
}
