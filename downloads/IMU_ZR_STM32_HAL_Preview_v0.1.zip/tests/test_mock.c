#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "imu_zr_hal.h"
static uint8_t regs[256];
static uint32_t tick;
HAL_StatusTypeDef HAL_I2C_Mem_Read(I2C_HandleTypeDef *h,uint16_t addr,uint16_t reg,uint16_t size,uint8_t *b,uint16_t n,uint32_t timeout){
  (void)h;(void)size;(void)timeout;
  if (addr != (0x6Au<<1)) return HAL_ERROR;
  memcpy(b,regs+reg,n);return HAL_OK;
}
HAL_StatusTypeDef HAL_I2C_Mem_Write(I2C_HandleTypeDef *h,uint16_t addr,uint16_t reg,uint16_t size,uint8_t *b,uint16_t n,uint32_t timeout){
  (void)h;(void)size;(void)timeout;
  if (addr != (0x6Au<<1)) return HAL_ERROR;
  memcpy(regs+reg,b,n);
  if (reg==0x12 && b[0]==0x01) regs[0x12]=0; /* completed reset */
  return HAL_OK;
}
void HAL_Delay(uint32_t ms){tick+=ms;}
uint32_t HAL_GetTick(void){return tick;}
int main(void){
  I2C_HandleTypeDef bus={0}; IMU_ZR_HAL_Handle d={0};IMU_ZR_HAL_Sample s={0};
  assert(IMU_ZR_HAL_Init(&d, &bus, 0)==IMU_ZR_HAL_NOT_FOUND);
  regs[0x0f]=0x6c;
  assert(IMU_ZR_HAL_Init(&d, &bus, 0)==IMU_ZR_HAL_OK);
  assert(d.address==0x6a && d.initialized);
  assert(regs[0x10]==0x48 && regs[0x11]==0x44 && regs[0x12]==0x44);
  s.ax_mps2=123.0f;
  assert(IMU_ZR_HAL_Read(&d,&s)==IMU_ZR_HAL_NOT_READY && s.ax_mps2==123.0f);
  regs[0x1e]=0x03;
  /* TEMP=0, gyro x=100, gyro y=-100, accel x=1000, accel z=8192 */
  regs[0x22]=0x64; regs[0x23]=0;
  regs[0x24]=0x9c; regs[0x25]=0xff;
  regs[0x28]=0xe8; regs[0x29]=0x03;
  regs[0x2c]=0x00; regs[0x2d]=0x20;
  assert(IMU_ZR_HAL_Read(&d,&s)==IMU_ZR_HAL_OK);
  assert(fabsf(s.gx_rads - 0.0305433f) < 0.0001f);
  assert(fabsf(s.gy_rads + 0.0305433f) < 0.0001f);
  assert(fabsf(s.ax_mps2 - 1.196411f) < 0.0005f);
  assert(fabsf(s.az_mps2 - 9.801f) < 0.01f);
  assert(s.temperature_c==25.0f);
  printf("STM32 HAL mock tests PASS\\n");
  return 0;
}
