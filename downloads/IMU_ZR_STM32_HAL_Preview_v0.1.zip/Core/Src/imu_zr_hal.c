#include "imu_zr_hal.h"

#define REG_FUNC_CFG_ACCESS 0x01u
#define REG_WHO_AM_I 0x0Fu
#define REG_CTRL1_XL 0x10u
#define REG_CTRL2_G 0x11u
#define REG_CTRL3_C 0x12u
#define REG_STATUS 0x1Eu
#define REG_OUT_TEMP_L 0x20u
#define LSM6DSOX_ID 0x6Cu
#define I2C_TIMEOUT_MS 100u

static HAL_StatusTypeDef read_reg(IMU_ZR_HAL_Handle *d,
                                  uint8_t reg, uint8_t *buf, uint16_t count) {
  return HAL_I2C_Mem_Read(d->hi2c, (uint16_t)(d->address << 1), reg,
                          I2C_MEMADD_SIZE_8BIT, buf, count, I2C_TIMEOUT_MS);
}
static HAL_StatusTypeDef write_reg(IMU_ZR_HAL_Handle *d, uint8_t reg, uint8_t data) {
  return HAL_I2C_Mem_Write(d->hi2c, (uint16_t)(d->address << 1), reg,
                           I2C_MEMADD_SIZE_8BIT, &data, 1, I2C_TIMEOUT_MS);
}
static int16_t signed_le16(const uint8_t *b) {
  const uint16_t raw = (uint16_t)b[0] | (uint16_t)((uint16_t)b[1] << 8);
  return (int16_t)((int32_t)raw - ((raw & 0x8000u) ? 65536 : 0));
}

IMU_ZR_HAL_Result IMU_ZR_HAL_Init(IMU_ZR_HAL_Handle *dev,
                                    I2C_HandleTypeDef *hi2c,
                                    uint8_t address) {
  if (dev == 0 || hi2c == 0 || (address != 0 && address != 0x6Au && address != 0x6Bu))
    return IMU_ZR_HAL_BAD_ARGUMENT;
  dev->hi2c = hi2c;
  dev->address = 0;
  dev->initialized = 0;
  uint8_t id = 0;
  if (address == 0) {
    for (uint8_t a = 0x6Au; a <= 0x6Bu; ++a) {
      dev->address = a;
      if (read_reg(dev, REG_WHO_AM_I, &id, 1) == HAL_OK && id == LSM6DSOX_ID) break;
    }
    if (dev->address > 0x6Bu || id != LSM6DSOX_ID) return IMU_ZR_HAL_NOT_FOUND;
  } else {
    dev->address = address;
    if (read_reg(dev, REG_WHO_AM_I, &id, 1) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
    if (id != LSM6DSOX_ID) return IMU_ZR_HAL_BAD_ID;
  }
  if (write_reg(dev, REG_FUNC_CFG_ACCESS, 0x00u) != HAL_OK ||
      write_reg(dev, REG_CTRL3_C, 0x01u) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
  uint8_t ctrl = 1;
  for (unsigned i=0;i<100;i++) {
    HAL_Delay(1);
    if (read_reg(dev, REG_CTRL3_C, &ctrl, 1) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
    if ((ctrl & 1u) == 0u) break;
  }
  if (ctrl & 1u) return IMU_ZR_HAL_RESET_TIMEOUT;
  if (write_reg(dev, REG_CTRL3_C, 0x44u) != HAL_OK ||
      write_reg(dev, REG_CTRL1_XL, 0x48u) != HAL_OK ||
      write_reg(dev, REG_CTRL2_G, 0x44u) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
  HAL_Delay(100); /* Settling; not gyro bias calibration */
  dev->initialized = 1;
  return IMU_ZR_HAL_OK;
}

IMU_ZR_HAL_Result IMU_ZR_HAL_Read(IMU_ZR_HAL_Handle *dev,
                                    IMU_ZR_HAL_Sample *sample) {
  if (dev == 0 || sample == 0 || dev->hi2c == 0 || !dev->initialized)
    return IMU_ZR_HAL_BAD_ARGUMENT;
  uint8_t status = 0;
  if (read_reg(dev, REG_STATUS, &status, 1) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
  if ((status & 0x03u) != 0x03u) return IMU_ZR_HAL_NOT_READY;
  uint8_t b[14];
  if (read_reg(dev, REG_OUT_TEMP_L, b, 14) != HAL_OK) return IMU_ZR_HAL_I2C_ERROR;
  const float gyro = 0.0175f * 0.017453292519943295f;
  const float accel = 0.000122f * 9.80665f;
  IMU_ZR_HAL_Sample next;
  next.temperature_c = 25.0f + (float)signed_le16(b) / 256.0f;
  next.gx_rads = (float)signed_le16(b+2) * gyro;
  next.gy_rads = (float)signed_le16(b+4) * gyro;
  next.gz_rads = (float)signed_le16(b+6) * gyro;
  next.ax_mps2 = (float)signed_le16(b+8) * accel;
  next.ay_mps2 = (float)signed_le16(b+10) * accel;
  next.az_mps2 = (float)signed_le16(b+12) * accel;
  next.host_timestamp_ms = HAL_GetTick();
  *sample = next;
  return IMU_ZR_HAL_OK;
}
