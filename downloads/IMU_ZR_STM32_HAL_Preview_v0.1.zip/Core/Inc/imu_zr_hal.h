#ifndef IMU_ZR_HAL_H
#define IMU_ZR_HAL_H

#include <stdint.h>
/* CubeMX generated main.h should import the family-specific STM32 HAL header. */
#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  IMU_ZR_HAL_OK = 0,
  IMU_ZR_HAL_NOT_READY,
  IMU_ZR_HAL_I2C_ERROR,
  IMU_ZR_HAL_NOT_FOUND,
  IMU_ZR_HAL_BAD_ID,
  IMU_ZR_HAL_RESET_TIMEOUT,
  IMU_ZR_HAL_BAD_ARGUMENT
} IMU_ZR_HAL_Result;

typedef struct {
  float ax_mps2, ay_mps2, az_mps2;
  float gx_rads, gy_rads, gz_rads;
  float temperature_c;
  uint32_t host_timestamp_ms; /* Time after reading, not the sensor sample instant. */
} IMU_ZR_HAL_Sample;

typedef struct {
  I2C_HandleTypeDef *hi2c;
  uint8_t address; /* 7-bit address 0x6A or 0x6B */
  uint8_t initialized;
} IMU_ZR_HAL_Handle;

/* Initializes LSM6DSOX: 104 Hz, +/-4 g, +/-500 dps, BDU+IF_INC.
   Tries 0x6A and 0x6B when address is 0; does not touch the magnetometer. */
IMU_ZR_HAL_Result IMU_ZR_HAL_Init(IMU_ZR_HAL_Handle *dev,
                                     I2C_HandleTypeDef *hi2c,
                                     uint8_t address);
/* Poll status; returns NOT_READY until both accel and gyro have new data. */
IMU_ZR_HAL_Result IMU_ZR_HAL_Read(IMU_ZR_HAL_Handle *dev,
                                     IMU_ZR_HAL_Sample *sample);

#ifdef __cplusplus
}
#endif
#endif
