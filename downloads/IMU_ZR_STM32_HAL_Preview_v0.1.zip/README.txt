Bozkurt Robotik BRX-100 | STM32Cube HAL Driver | Integration Preview v0.1

Scope
The I2C driver reads triaxial acceleration and angular rate from the
LSM6DSOX. Configuration: 104 Hz, +/-4 g and +/-500 degrees/s. It detects
the LSM6DSOX at address 0x6A or 0x6B. The MMC5603NJ magnetometer, FIFO,
interrupt handling and sensor fusion are outside this driver's scope.

Integration
- Enable an I2C peripheral in STM32CubeMX.
- Add Core/Src/imu_zr_hal.c to your project and Core/Inc to the include path.
- The driver uses the generated main.h and blocking HAL I2C calls.
- See Core/Src/main_usage_snippet.txt for initialization and read examples.
- Apply 3.3 to 5 V DC to BRX-100 VIN. Use 3.3 V-compatible I2C logic.
- Set CS high for I2C mode. SDO/SA0 selects the LSM6DSOX address.
- Check units, axis mapping and calibration in your application.

Validation
Host-side mock HAL checks cover the software integration. Physical STM32
hardware integration remains in preview.

Datasheet
https://bozkurtrobotik.com/docs/BRX-100_Datasheet_RevC.pdf
