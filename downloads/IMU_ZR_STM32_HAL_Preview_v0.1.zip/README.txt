Bozkurt Robotik BR-IMU-M1 — STM32Cube HAL SIX-AXIS DRIVER PREVIEW v0.1

This package is a NEW source-level integration adapter derived from the
IMU_ZR Arduino 0.2.1 LSM6DSOX configuration/scale logic. It is not an
already-hardware-validated native STM32 release.

Includes:
 Core/Inc/imu_zr_hal.h, Core/Src/imu_zr_hal.c
 Core/Src/main_usage_snippet.txt

Requirements: STM32Cube HAL with enabled I2C peripheral. Include the
family's generated main.h via compiler header path. CubeMX-generated main.h
normally includes stm32..._hal.h. Add the .c to compiler sources and .h
include directory. This driver uses blocking HAL_I2C_Mem_Read/Write and HAL_Delay.

Sensor configuration: 104 Hz, +/-4g, +/-500 dps, 6 axes, 0x6A/0x6B autodetect.
The MMC5603 magnetometer is NOT yet supported in this HAL adapter.
Not calibrated; no FIFO, IRQ, fusion or safety qualification. All 9 axes
require further sensor-bus verification; the tested board's magnetometer
previously did not respond.

STM32 electrical I2C pins MUST be 3.3V logic. CS to 3.3V for I2C;
SA0 determines address. Power VIN according to validated board electrical data.
Check output units and frame mapping before your application.

Checks: host-based mock HAL compile/tests; not verified on physical STM32.
See Arduino package VALIDATION.md for separate original board evidence.
