#include <IMU_ZR.h>

IMU_ZR imu;
bool running = false;
uint32_t sequence = 0;

bool readRegisters(uint8_t reg, uint8_t *data, uint8_t length) {
  Wire.beginTransmission(imu.address());
  Wire.write(reg);
  uint8_t status = Wire.endTransmission(false);
  if (status != 0) {
    Serial.print("ERROR_I2C "); Serial.println(status); return false;
  }
  if (Wire.requestFrom(imu.address(), length) != length) {
    while (Wire.available()) Wire.read();
    Serial.println("ERROR_SHORT_READ"); return false;
  }
  for (uint8_t i = 0; i < length; ++i) data[i] = uint8_t(Wire.read());
  return true;
}

int32_t signed16(const uint8_t *p) {
  const uint16_t value = uint16_t(p[0]) | (uint16_t(p[1]) << 8);
  return value & 0x8000U ? int32_t(value) - 65536L : int32_t(value);
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  delay(100);
  if (!imu.begin(Wire, 0, false, IMU_ZR::DataRate::Hz104)) {
    Serial.println(IMU_ZR::errorText(imu.lastError())); return;
  }
  Serial.print("#ADDRESS=0x"); Serial.println(imu.address(), HEX);
  const uint8_t registers[] = {0x0F, 0x10, 0x11, 0x12, 0x15, 0x16, 0x17};
  uint8_t values[sizeof(registers)];
  for (uint8_t i = 0; i < sizeof(registers); ++i) {
    if (!readRegisters(registers[i], &values[i], 1)) return;
    Serial.print("#REG_0x"); Serial.print(registers[i], HEX);
    Serial.print("=0x"); Serial.println(values[i], HEX);
  }
  // Check identity, 104 Hz / +/-4 g, 104 Hz / +/-500 dps, BDU + IF_INC.
  if (values[0] != 0x6C || values[1] != 0x48 ||
      values[2] != 0x44 || values[3] != 0x44 ||
      (values[4] & 0x10) || (values[5] & 0x80) || (values[6] & 0x02)) {
    Serial.println("ERROR_CONFIGURATION"); return;
  }
  Serial.println("#CONFIG_OK 104Hz accel=4g gyro=500dps BDU=1 IF_INC=1");
  delay(1000); // settle before recording; no bias correction
  uint8_t discard[14];
  if (!readRegisters(0x20, discard, sizeof(discard))) return;
  Serial.println("sequence,timestamp_us,ax_raw,ay_raw,az_raw,gx_raw,gy_raw,gz_raw,temp_raw");
  running = true;
}

void loop() {
  if (!running) { delay(100); return; }
  uint8_t status, data[14];
  if (!readRegisters(0x1E, &status, 1)) { delay(20); return; }
  if ((status & 0x03) != 0x03) return;
  if (!readRegisters(0x20, data, sizeof(data))) { delay(20); return; }
  const uint32_t timestamp = micros();
  Serial.print(sequence++); Serial.print(','); Serial.print(timestamp);
  // Signed raw outputs; host applies datasheet sensitivities without rounding.
  const uint8_t offsets[] = {8, 10, 12, 2, 4, 6, 0};
  for (uint8_t i = 0; i < sizeof(offsets); ++i) {
    Serial.print(','); Serial.print(signed16(data + offsets[i]));
  }
  Serial.println();
}
