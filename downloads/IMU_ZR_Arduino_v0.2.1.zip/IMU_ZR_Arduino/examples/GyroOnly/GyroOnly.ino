#include <IMU_ZR.h>

IMU_ZR imu;
bool running = false;
uint32_t lastOutputMs = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  delay(100);
  running = imu.beginGyro(Wire); // automatic address, 104 Hz, +/-500 deg/s
  if (!running) { Serial.println(IMU_ZR::errorText(imu.lastError())); return; }
  Serial.print("GYRO_ONLY_OK address=0x"); Serial.println(imu.address(), HEX);
  Serial.println("Accelerometer OFF; magnetometer OFF; gyro 104 Hz; CSV approx 50 Hz");
  Serial.println("timestamp_us,gx_dps,gy_dps,gz_dps");
}

void loop() {
  if (!running) { delay(100); return; }
  if (uint32_t(millis() - lastOutputMs) < 20) return;
  lastOutputMs = millis();
  IMU_ZR::GyroSample s;
  if (!imu.readGyro(s)) {
    if (imu.lastError() != IMU_ZR::Error::NotReady)
      Serial.println(IMU_ZR::errorText(imu.lastError()));
    return;
  }
  // Library returns rad/s; this example displays degrees/s.
  constexpr float RAD_TO_DEGREES = 57.29577951308232f;
  Serial.print(s.timestampUs); Serial.print(',');
  Serial.print(s.angularRate.x * RAD_TO_DEGREES, 4); Serial.print(',');
  Serial.print(s.angularRate.y * RAD_TO_DEGREES, 4); Serial.print(',');
  Serial.println(s.angularRate.z * RAD_TO_DEGREES, 4);
}
