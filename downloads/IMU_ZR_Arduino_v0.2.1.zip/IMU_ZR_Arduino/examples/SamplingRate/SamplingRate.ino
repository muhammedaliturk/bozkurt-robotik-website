#include <IMU_ZR.h>
IMU_ZR imu;
bool running = false;
uint32_t startedMs, samples = 0, errors = 0, maximumReadUs = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(400000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  // Change this enum to select the sensor ODR; achievable read rate is measured.
  running = imu.begin(Wire, 0, false, IMU_ZR::DataRate::Hz208);
  if (!running) { Serial.println(IMU_ZR::errorText(imu.lastError())); return; }
  Serial.print("Configured ODR Hz="); Serial.println(imu.dataRateHz());
  Serial.println("window_ms,read_samples,observed_Hz,errors,max_call_us");
  startedMs = millis();
}

void loop() {
  if (!running) { delay(100); return; }
  IMU_ZR::ImuSample s;
  const uint32_t start = micros();
  const bool ok = imu.readImu(s);
  const uint32_t elapsed = micros() - start;
  if (elapsed > maximumReadUs) maximumReadUs = elapsed;
  if (ok) ++samples;
  else if (imu.lastError() != IMU_ZR::Error::NotReady) ++errors;
  const uint32_t window = millis() - startedMs;
  if (window >= 1000) {
    Serial.print(window); Serial.print(',');
    Serial.print(samples); Serial.print(',');
    Serial.print(samples * 1000.0f / window, 2); Serial.print(',');
    Serial.print(errors); Serial.print(','); Serial.println(maximumReadUs);
    startedMs = millis(); samples = errors = maximumReadUs = 0;
  }
}
