#include <IMU_ZR.h>
IMU_ZR imu;

void scanBus() {
  uint8_t count = 0;
  uint8_t statusCounts[6] = {};
  for (uint8_t address = 8; address < 120; ++address) {
    Wire.beginTransmission(address);
    const uint8_t status = Wire.endTransmission();
    if (status < 6) ++statusCounts[status];
    if (status == 0) {
      Serial.print("ACK: 0x"); Serial.println(address, HEX);
      ++count;
    }
  }
  Serial.print("Wire status counts [0..5]: ");
  for (uint8_t i = 0; i < 6; ++i) { Serial.print(statusCounts[i]); Serial.print(' '); }
  Serial.println();
  Serial.print("SDA level: "); Serial.print(digitalRead(SDA));
  Serial.print(" SCL level: "); Serial.println(digitalRead(SCL));
  if (!count) Serial.println("No I2C devices. Check power, GND, CS, SDA/SCL and level shifting.");
}

void reportError() {
  Serial.println(IMU_ZR::errorText(imu.lastError()));
  if (imu.lastError() == IMU_ZR::Error::Bus ||
      imu.lastError() == IMU_ZR::Error::ShortRead) {
    Serial.print("Failed device: 0x"); Serial.println(imu.lastBusAddress(), HEX);
    Serial.print("Register: 0x"); Serial.println(imu.lastBusRegister(), HEX);
    Serial.print("Wire status: "); Serial.println(imu.lastWireStatus());
    Serial.println("1=buffer, 2=address NACK, 3=data NACK, 4=other; 0 with ShortRead=incomplete response.");
  }
}

bool validImu(uint8_t address) {
  Wire.beginTransmission(address);
  Wire.write(uint8_t(0x0F));
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(address, uint8_t(1)) != 1) return false;
  return Wire.read() == 0x6C;
}

void setup() {
  Serial.begin(115200);
  const uint32_t start = millis();
  while (!Serial && millis() - start < 3000) {}
  Wire.begin();
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  delay(100);
  Serial.println("IMU_ZR diagnostics - power-cycle the sensor before running.");
  Serial.println("Initial bus scan (0x30 may be hidden until pass-through is enabled):");
  scanBus();
  uint8_t address = 0;
  if (validImu(0x6A)) address = 0x6A;
  else if (validImu(0x6B)) address = 0x6B;
  if (!address) {
    Serial.println("No LSM6DSOX WHO_AM_I=0x6C at 0x6A/0x6B.");
    Serial.println("Hold CS at 3.3V. SA0=GND selects 0x6A; SA0=3.3V selects 0x6B.");
    return;
  }
  Serial.print("LSM6DSOX detected at 0x"); Serial.println(address, HEX);
  if (!imu.begin(Wire, address, false)) { reportError(); return; }
  Serial.println("Accelerometer/gyro initialization OK.");
  if (!imu.begin(Wire, address, true)) {
    Serial.println("Full initialization failed:"); reportError();
    Serial.println("Bus scan after initialization attempt:"); scanBus();
    return;
  }
  Serial.println("Both sensor identities and initialization OK.");
  scanBus();
  IMU_ZR::MagSample s;
  if (imu.readMagBlocking(s)) Serial.println("Magnetic conversion OK.");
  else reportError();
}

void loop() {}
