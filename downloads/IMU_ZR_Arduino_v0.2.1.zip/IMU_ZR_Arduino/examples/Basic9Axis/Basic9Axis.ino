#include <IMU_ZR.h>

IMU_ZR imu;
bool running = false;

void setup() {
  Serial.begin(115200);
  const uint32_t start = millis();
  while (!Serial && millis() - start < 3000) {}
  Wire.begin(); // For custom pins, configure Wire here using your board's API.
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  // J1.6 (CS) must be held at 3.3V; J1.5 (SA0) LOW selects 0x6A.
  // Optional nine-axis mode requires a working MMC5603 auxiliary connection.
  running = imu.begin(Wire, 0, true);
  if (!running) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
    return;
  }
  Serial.println("ax_mps2,ay_mps2,az_mps2,gx_rads,gy_rads,gz_rads,mx_uT,my_uT,mz_uT,temp_C");
}

void loop() {
  if (!running) { delay(100); return; }
  IMU_ZR::ImuSample motion;
  IMU_ZR::MagSample magnetic;
  if (!imu.readImu(motion)) {
    if (imu.lastError() != IMU_ZR::Error::NotReady)
      Serial.println(IMU_ZR::errorText(imu.lastError()));
    delay(1);
    return;
  }
  if (!imu.readMagBlocking(magnetic)) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
    delay(20);
    return;
  }
  // These two readings have separate acquisition times and native sensor axes.
  Serial.print(motion.acceleration.x, 5); Serial.print(',');
  Serial.print(motion.acceleration.y, 5); Serial.print(',');
  Serial.print(motion.acceleration.z, 5); Serial.print(',');
  Serial.print(motion.angularRate.x, 5); Serial.print(',');
  Serial.print(motion.angularRate.y, 5); Serial.print(',');
  Serial.print(motion.angularRate.z, 5); Serial.print(',');
  Serial.print(magnetic.magneticField.x, 3); Serial.print(',');
  Serial.print(magnetic.magneticField.y, 3); Serial.print(',');
  Serial.print(magnetic.magneticField.z, 3); Serial.print(',');
  Serial.println(motion.temperature, 2);
  delay(20);
}
