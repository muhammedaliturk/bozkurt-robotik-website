#include <IMU_ZR.h>
IMU_ZR imu;
bool running = false;
uint32_t lastOutputMs = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  delay(100);
  // Default: auto address, six axes, 104 Hz sensor ODR.
  running = imu.begin(Wire);
  if (!running) { Serial.println(IMU_ZR::errorText(imu.lastError())); return; }
  Serial.print("IMU_6AXIS_OK address=0x"); Serial.println(imu.address(), HEX);
  Serial.print("Sensor ODR Hz="); Serial.print(imu.dataRateHz());
  Serial.print(" nominal period us="); Serial.println(imu.samplePeriodUs());
  Serial.println("timestamp_us,ax_mps2,ay_mps2,az_mps2,gx_rads,gy_rads,gz_rads,temp_C");
}
void loop() {
  if (!running) { delay(100); return; }
  if (uint32_t(millis() - lastOutputMs) < 20) return; // approx. 50 Hz serial output
  lastOutputMs = millis();
  IMU_ZR::ImuSample s;
  if (imu.readImu(s)) {
    Serial.print(s.timestampUs); Serial.print(',');
    Serial.print(s.acceleration.x, 5); Serial.print(',');
    Serial.print(s.acceleration.y, 5); Serial.print(',');
    Serial.print(s.acceleration.z, 5); Serial.print(',');
    Serial.print(s.angularRate.x, 6); Serial.print(',');
    Serial.print(s.angularRate.y, 6); Serial.print(',');
    Serial.print(s.angularRate.z, 6); Serial.print(',');
    Serial.println(s.temperature, 2);
  } else if (imu.lastError() != IMU_ZR::Error::NotReady) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
  }
}
