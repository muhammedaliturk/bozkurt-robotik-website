"""Compile and execute the actual driver against a fake Wire bus on Windows/MSVC."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DriverTests(unittest.TestCase):
    def test_driver_behavior(self):
        vswhere = Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Microsoft Visual Studio/Installer/vswhere.exe"
        install = subprocess.check_output(
            [str(vswhere), "-latest", "-products", "*", "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64", "-property", "installationPath"],
            text=True).strip()
        self.assertTrue(install, "MSVC C++ build tools required")
        vcvars = Path(install) / "VC/Auxiliary/Build/vcvars64.bat"
        with tempfile.TemporaryDirectory(prefix="imu_zr_tests_") as directory:
            runner = Path(directory) / "run.cmd"
            runner.write_text(
                f'@echo off\ncall "{vcvars}" >nul\n'
                f'cl /nologo /EHsc /std:c++14 /W4 /WX /I"{ROOT / "tests/mocks"}" /I"{ROOT / "src"}" '
                f'"{ROOT / "src/IMU_ZR.cpp"}" "{ROOT / "tests/driver_tests.cpp"}" /Fe:driver_tests.exe\n'
                'if errorlevel 1 exit /b 1\ndriver_tests.exe\n', encoding="utf-8")
            result = subprocess.run(["cmd.exe", "/d", "/c", str(runner)], cwd=directory,
                                    text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertRegex(result.stdout, r"\d+ driver checks passed")
            print(result.stdout.strip())


if __name__ == "__main__":
    unittest.main()
