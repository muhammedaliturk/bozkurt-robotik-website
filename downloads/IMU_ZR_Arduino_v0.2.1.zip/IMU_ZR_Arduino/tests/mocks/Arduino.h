#pragma once
#include <cstdint>
#include <cstddef>
extern uint32_t fakeMs;
inline uint32_t millis() { return fakeMs; }
inline uint32_t micros() { return fakeMs * 1000U; }
inline void delay(uint32_t ms) { fakeMs += ms; }
