#pragma once
#include "Arduino.h"
#include <vector>
#include <cstring>

class TwoWire {
public:
  uint8_t imu[256] = {}, hub[256] = {}, mag[256] = {};
  uint8_t address = 0, reg = 0;
  uint8_t presentImuAddress = 0; // zero accepts either address for older tests
  bool magPresent = true;
  unsigned magTransactions = 0;
  bool hubBank = false, nack = false, shortRead = false;
  bool resetStuck = false, conversionStuck = false, failMasterWrite = false;
  bool failBankRestore = false;
  std::vector<uint8_t> tx, rx;
  size_t readPos = 0;
  TwoWire() { imu[0x0F] = 0x6C; mag[0x39] = 0x10; }
  void beginTransmission(uint8_t addr) {
    address = addr; tx.clear(); if (addr == 0x30) ++magTransactions;
  }
  size_t write(uint8_t b) { tx.push_back(b); return 1; }
  uint8_t endTransmission(bool = true) {
    if (nack) return 2;
    if (address == 0x30 && !magPresent) return 2;
    if (address != 0x30 && presentImuAddress && address != presentImuAddress) return 2;
    if (tx.empty()) return 4;
    reg = tx[0];
    if (tx.size() == 1) return 0;
    const uint8_t val = tx[1];
    if (address == 0x30) {
      mag[reg] = val;
      if (reg == 0x1B && (val & 1)) mag[0x18] = conversionStuck ? 0 : 0x40;
    } else {
      if (reg == 1) {
        if (hubBank && val == 0 && failBankRestore) return 3;
        hubBank = (val & 0x40) != 0; return 0;
      }
      if (hubBank && reg == 0x14 && failMasterWrite) return 3;
      (hubBank ? hub : imu)[reg] = val;
      if (!hubBank && reg == 0x12 && (val & 1) && !resetStuck) imu[reg] = 0;
    }
    return 0;
  }
  size_t requestFrom(uint8_t addr, uint8_t n) {
    rx.clear(); readPos = 0;
    const uint8_t count = shortRead ? uint8_t(n - 1) : n;
    const uint8_t *registers = addr == 0x30 ? mag : (hubBank ? hub : imu);
    for (uint8_t i = 0; i < count; ++i) rx.push_back(registers[uint8_t(reg + i)]);
    if (addr == 0x30 && reg == 0 && count == 9) mag[0x18] &= uint8_t(~0x40);
    return count;
  }
  int available() { return int(rx.size() - readPos); }
  int read() { return available() ? rx[readPos++] : -1; }
};
extern TwoWire Wire;
