#include <IMU_ZR.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>

uint32_t fakeMs = 0;
TwoWire Wire;
int checks = 0;
void check(bool ok, const char *message) {
  ++checks;
  if (!ok) { std::fprintf(stderr, "FAIL: %s\n", message); std::exit(1); }
}
bool near(float a, float b) { return std::fabs(a-b) < 0.0002f; }
void put16(TwoWire &w, uint8_t reg, uint16_t u) {
  w.imu[reg] = uint8_t(u); w.imu[reg+1] = uint8_t(u >> 8);
}
void put20(TwoWire &w, int axis, uint32_t u) {
  w.mag[axis*2] = uint8_t(u >> 12);
  w.mag[axis*2+1] = uint8_t(u >> 4);
  w.mag[6+axis] = uint8_t((u & 15) << 4);
}
int main() {
  IMU_ZR d;
  IMU_ZR::ImuSample s = {};
  IMU_ZR::MagSample m = {};
  check(!d.readImu(s) && d.lastError() == IMU_ZR::Error::NotInitialized, "uninitialized IMU");
  TwoWire w;
  check(!d.begin(w, 0x68) && d.lastError() == IMU_ZR::Error::InvalidAddress, "invalid address");
  w.imu[0x0F] = 0;
  check(!d.begin(w, 0x6A, true) && d.lastError() == IMU_ZR::Error::WrongImuId, "wrong identity");
  w.imu[0x0F] = 0x6C; w.nack = true;
  check(!d.begin(w, 0x6A, true) && d.lastError() == IMU_ZR::Error::Bus, "NACK propagates");
  check(d.lastBusAddress() == 0x6A && d.lastBusRegister() == 1 && d.lastWireStatus() == 2,
        "I2C diagnostics preserve failing address, register and status");
  w.nack = false; w.resetStuck = true;
  check(!d.begin(w, 0x6A, true) && d.lastError() == IMU_ZR::Error::Timeout, "reset timeout");
  w.resetStuck = false;
  check(d.begin(w, 0x6A, true) && d.magInitialized(), "initialize both sensors");
  check(!w.hubBank && w.hub[0x14] == 0x10, "pass-through and bank restoration");
  s.temperature = 123;
  check(!d.readImu(s) && d.lastError() == IMU_ZR::Error::NotReady && s.temperature == 123,
        "not-ready output stays unchanged");
  w.imu[0x1E] = 3;
  put16(w, 0x20, 0xFF00); // -256 -> 24 C
  put16(w, 0x22, 0x8000); put16(w, 0x24, 0x7FFF); put16(w, 0x26, 0xFFFF);
  put16(w, 0x28, 0x8000); put16(w, 0x2A, 0x7FFF); put16(w, 0x2C, 0);
  check(d.readImu(s) && near(s.temperature, 24), "temperature signed conversion");
  check(near(s.acceleration.x, -39.203990f) && near(s.acceleration.y, 39.202794f)
        && s.acceleration.z == 0, "acceleration endpoints and scale");
  check(near(s.angularRate.x, -10.008288f) && s.angularRate.y > 10.0f
        && near(s.angularRate.z, -0.0003054326f), "gyro endpoints and rad/s scale");
  const float old = s.temperature;
  w.shortRead = true;
  check(!d.readImu(s) && d.lastError() == IMU_ZR::Error::ShortRead && s.temperature == old,
        "short read does not publish partial sample");
  w.shortRead = false;
  put20(w, 0, 524288); put20(w, 1, 540672); put20(w, 2, 507904);
  check(d.readMagBlocking(m) && near(m.magneticField.x, 0)
        && near(m.magneticField.y, 100) && near(m.magneticField.z, -100), "20-bit offset and microtesla");
  put20(w, 0, 524289); put20(w, 1, 0); put20(w, 2, 1048575);
  check(d.readMagBlocking(m) && near(m.magneticField.x, 0.006103515625f)
        && near(m.magneticField.y, -3200) && near(m.magneticField.z, 3199.993896484375f),
        "magnetic low nibble and unsigned endpoints");
  check(d.startMagMeasurement(), "start async conversion");
  check(!d.startMagMeasurement() && d.lastError() == IMU_ZR::Error::Busy, "pending conversion busy");
  check(d.readMag(m), "finish async conversion");
  w.conversionStuck = true; const float magOld = m.magneticField.z;
  check(!d.readMagBlocking(m) && d.lastError() == IMU_ZR::Error::Timeout
        && m.magneticField.z == magOld, "conversion timeout and unchanged output");
  fakeMs = 0xFFFFFFF0UL;
  check(!d.readMagBlocking(m) && d.lastError() == IMU_ZR::Error::Timeout,
        "conversion timeout handles clock wraparound");
  w.conversionStuck = false; w.mag[0x39] = 0;
  check(!d.begin(w, 0x6A, true) && d.lastError() == IMU_ZR::Error::WrongMagId
        && d.imuInitialized() && !d.magInitialized(), "mag ID failure retains usable IMU");
  check(d.begin(w, 0x6B, false) && !d.magInitialized(), "IMU-only at alternate address");
  check(!d.startMagMeasurement() && d.lastError() == IMU_ZR::Error::NotInitialized,
        "IMU-only rejects magnetic requests");
  w.mag[0x39] = 0x10; w.failMasterWrite = true;
  check(!d.begin(w, 0x6A, true) && d.lastError() == IMU_ZR::Error::Bus && !w.hubBank,
        "failed bank operation restores user bank");
  w.failMasterWrite = false; w.failBankRestore = true;
  check(!d.begin(w, 0x6A, true) && !d.imuInitialized(), "unknown register bank invalidates IMU state");
  TwoWire autoWire;
  IMU_ZR six;
  autoWire.presentImuAddress = 0x6B;
  autoWire.magPresent = false;
  check(six.begin(autoWire) && six.address() == 0x6B && six.lastError() == IMU_ZR::Error::None
        && six.lastWireStatus() == 0, "default auto-detection skips absent 0x6A");
  check(near(six.dataRateHz(), 104) && six.samplePeriodUs() == 9615, "default ODR and nominal period");
  check(!six.magInitialized() && autoWire.magTransactions == 0, "six-axis default never accesses missing magnetometer");
  autoWire.presentImuAddress = 0x6A;
  check(six.begin(autoWire) && six.address() == 0x6A, "auto-detection handles address change");
  const float rates[] = {12.5f, 26, 52, 104, 208, 416, 833, 1660, 3330, 6660};
  for (uint8_t i = 0; i < 10; ++i) {
    check(six.begin(autoWire, 0, false, static_cast<IMU_ZR::DataRate>(i + 1)) &&
          near(six.dataRateHz(), rates[i]) &&
          six.samplePeriodUs() == uint32_t(1000000.0f / rates[i] + 0.5f) &&
          autoWire.imu[0x10] == uint8_t(((i + 1) << 4) | 8) &&
          autoWire.imu[0x11] == uint8_t(((i + 1) << 4) | 4), "ODR selection retains physical scales");
  }
  check(!six.begin(autoWire, 0, false, static_cast<IMU_ZR::DataRate>(0)) &&
        six.lastError() == IMU_ZR::Error::InvalidRate && !six.imuInitialized(), "reject power-down as sample rate");
  check(!six.begin(autoWire, 0, false, static_cast<IMU_ZR::DataRate>(11)) &&
        six.lastError() == IMU_ZR::Error::InvalidRate, "reject reserved sample rate");
  autoWire.imu[0x0F] = 0;
  check(!six.begin(autoWire) && six.lastError() == IMU_ZR::Error::NotFound, "auto mode rejects incorrect identity");
  autoWire.nack = true;
  check(!six.begin(autoWire) && six.lastError() == IMU_ZR::Error::NotFound, "auto mode reports no sensor");
  autoWire.nack = false; autoWire.imu[0x0F] = 0x6C;
  check(!six.begin(autoWire, 0x6B) && six.lastError() == IMU_ZR::Error::Bus, "explicit address never silently changes");
  TwoWire gyroWire;
  gyroWire.presentImuAddress = 0x6B; gyroWire.magPresent = false;
  IMU_ZR gyro;
  IMU_ZR::GyroSample g = {};
  check(!gyro.readGyro(g) && gyro.lastError() == IMU_ZR::Error::NotInitialized,
        "uninitialized gyro read rejected");
  check(gyro.beginGyro(gyroWire) && gyro.address() == 0x6B &&
        gyroWire.imu[0x10] == 0 && gyroWire.imu[0x11] == 0x44 &&
        gyroWire.magTransactions == 0, "gyro-only powers down accel and skips mag");
  check(!gyro.readImu(s) && gyro.lastError() == IMU_ZR::Error::WrongMode,
        "six-axis read rejected while accelerometer disabled");
  gyroWire.imu[0x1E] = 1;
  g.angularRate.x = 999;
  check(!gyro.readGyro(g) && gyro.lastError() == IMU_ZR::Error::NotReady &&
        g.angularRate.x == 999, "gyro waits for GDA, ignores accelerometer readiness");
  gyroWire.imu[0x1E] = 2;
  put16(gyroWire, 0x22, 0x8000); put16(gyroWire, 0x24, 0x7FFF); put16(gyroWire, 0x26, 0xFFFF);
  check(gyro.readGyro(g) && near(g.angularRate.x, -10.008288f) &&
        g.angularRate.y > 10 && near(g.angularRate.z, -0.0003054326f),
        "gyro-only signed conversions without accelerometer data");
  gyroWire.shortRead = true; const float gyroOld = g.angularRate.x;
  check(!gyro.readGyro(g) && gyro.lastError() == IMU_ZR::Error::ShortRead &&
        g.angularRate.x == gyroOld, "gyro incomplete read preserves sample");
  gyroWire.shortRead = false;
  check(gyro.beginGyro(gyroWire, 0, IMU_ZR::DataRate::Hz208) &&
        gyroWire.imu[0x10] == 0 && gyroWire.imu[0x11] == 0x54,
        "gyro-only rate selection keeps accelerometer off");
  check(gyro.begin(gyroWire) && gyroWire.imu[0x10] == 0x48,
        "can restore six-axis mode after gyro-only");
  std::printf("%d driver checks passed\n", checks);
  return 0;
}
