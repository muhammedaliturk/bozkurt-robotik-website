﻿# Doğrulama — IMU_ZR 0.2.0

Tarih: 2026-11-04.

## Yazılım kontrolleri

`python -m unittest discover -s tests -v` başarılı. Gerçek `src/IMU_ZR.cpp`, MSVC `/W4 /WX` ile sahte Arduino/Wire ortamında derlenip çalıştırıldı: **44 davranış kontrolü geçti**.

Kapsam: altı eksen varsayılanında manyetometreye hiç erişmeme; otomatik 0x6A/0x6B seçimi; yanlış kimlik/eksik aygıt; belirtilen adrese bağlı kalma; on ODR ayarı ve sabit ölçüm ölçekleri; geçersiz ODR reddi; NACK ve eksik okuma; reset/ölçüm zaman aşımı ve sayaç taşması; 16-bit işaret dönüşümü; 20-bit manyetik veri; başarısız okumada çıkışın korunması; register bankasına dönüş.

## Arduino derlemeleri

Arduino AVR core 1.8.8 kullanıldı.

| Kart | Örnek | Sonuç |
|---|---|---|
| Mega 2560 | ImuOnly | Başarılı |
| Mega 2560 | SamplingRate | Başarılı |
| Mega 2560 | Basic9Axis | Başarılı |
| Mega 2560 | Diagnostics | Başarılı |
| Uno | ImuOnly | Başarılı |

## Donanım kanıtı ve sınırlar

Önceki sürümün altı eksen yolu Mega 2560 ve gerçek LSM6DSOX üzerinde çalıştırıldı: yaklaşık 49,99 Hz seri çıktı hızında 441 geçerli örnek, bu kayıt sırasında hata mesajı yok. Sensör ODR ayarı 104 Hz idi. Ortalama ivme (-0,192861; 0,049397; 9,921736) m/s²; açısal hız (0,013594; 0,002364; -0,000334) rad/s. Bu ölçümler kalibrasyonsuzdur.

**0.2.0 canlı yükleme denemesi COM6 erişim engellendi hatasıyla tamamlanamadı.** Yeni otomatik adres ve ODR API'si yazılım testleri/derlemelerle doğrulandı; yeni sürümün donanım kabul testi ve seçilebilir yüksek hızların kayıpsız aktarımı henüz doğrulanmadı. Başarısız yükleme denemesi karttaki önceki programı değiştirmedi.

Mevcut kartta manyetometre önceki testlerde yanıt vermedi. Bu nedenle varsayılan kullanım altı eksendir. Paket nominal 6,66 kHz sensör ayarına izin verir; bu, Mega/I²C/seri hat üzerinden 6,66 kHz kayıpsız kayıt garantisi değildir. FIFO kullanılmadığından hızlı ayarlarda ara örnekler kaybolabilir.

## 0.2.1 — yalnız jiroskop modu

52 davranış kontrolü geçti. Yeni kontroller ivmeölçerin güç tasarrufu durumuna alınmasını, manyetometreye erişilmemesini, GDA hazır bayrağıyla okuma, eksik okuma ve işaret/ölçek dönüşümlerini, hız seçimini ve altı eksene geri dönüşü kapsar. GyroOnly Mega 2560 için derlendi. İlk donanım yükleme denemesinde COM6 erişim engellendi hatası alındı; yeni jiroskop ölçümü henüz alınamadı.

### 0.2.1 canlı jiroskop doğrulaması

COM6 serbest bırakıldıktan sonra GyroOnly Mega 2560'a başarıyla yüklendi. LSM6DSOX 0x6A adresinde bulundu; yazılım ivmeölçeri kapattı, manyetometreyi başlatmadı. 104 Hz jiroskop ayarıyla yaklaşık 49,988 Hz seri çıktı hızında 441 örnek kaydedildi. Bu kayıtta hata mesajı görülmedi. Ortalama XYZ açısal hızları (0,749603; 0,137897; -0,013651) °/s. Kalibrasyon veya ofset çıkarma uygulanmadı. Sonuçlar LIVE_GYRO.csv ve LIVE_GYRO_SERIAL.txt dosyalarında tutulur. GyroOnly, Uno için de derlendi; ImuOnly Mega regresyon derlemesi başarılıdır.

### Datasheet6DoF donanım kaydı

Mega üzerinde register geri okuması WHO_AM_I=0x6C, CTRL1_XL=0x48, CTRL2_G=0x44, CTRL3_C=0x44 olarak doğrulandı. Yaklaşık 20 saniyede 2040 örnek alındı; gözlenen okuma hızı 102,778 Hz, ortalama host okuma aralığı 9,7297 ms. Hata mesajı veya seri sıra numarası atlaması yok. Ham/fiziksel CSV ve ölçüm raporu `measurements/six_dof_datasheet` altında. Bu kayıt tam datasheet performans uygunluk testi değildir. Mega şu anda Datasheet6DoF ham veri örneğini çalıştırıyor.
