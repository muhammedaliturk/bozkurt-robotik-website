﻿# IMU_ZR Arduino — 0.2.1

LSM6DSOX için altı eksen Arduino sürücüsü. Varsayılan kullanım manyetometreyi başlatmaz. Mega 2560 üzerinde çalışan ivme/jiroskop yoluna göre hazırlanmıştır. Wire dışında bağımlılık yoktur.

## Kurulum ve ilk ölçüm

Arduino IDE → Sketch → Include Library → Add .ZIP Library ile `IMU_ZR_Arduino.zip` dosyasını ekleyin. Eski IMU_ZR kopyası kuruluysa aynı kütüphanenin birden fazla kopyasını bırakmadan güncelleyin. File → Examples → IMU_ZR → **ImuOnly** örneğini açın. Mega için kartı **Arduino Mega or Mega 2560** seçin; Seri Monitör **115200 baud** olmalıdır.

ImuOnly altı ekseni ve sıcaklığı CSV olarak yaklaşık 50 Hz'de gönderir. Sensörün kendi ölçüm hızı 104 Hz'dir. `0x6A` ve `0x6B` adreslerini kütüphane otomatik kontrol eder.

## Bağlantı

| IMU J1 | İşlev | Mega 2560 |
|---|---|---|
| 1 | VIN | Kartın regülatörüne uygun besleme |
| 2 | GND | GND |
| 3 | SCL | D21 / SCL |
| 4 | SDA | D20 / SDA |
| 5 | SA0 | GND → 0x6A; 3,3 V → 0x6B |
| 6 | CS | 3,3 V |
| 7 | INT2 | Bu sürümde boş bırakılabilir |

Uno'da SDA=A4, SCL=A5'tir. Sensör lojik seviyesi 3,3 V'tur; 5 V Arduino ile uygun çift yönlü I²C seviye dönüştürücü kullanın. CS ve SA0'ı sabit seviyeye bağlayın. VIN, regülatör girişidir; sensör beslemesi ve lojik pinlerine 5 V uygulanmaz.

## API

```cpp
#include <IMU_ZR.h>
IMU_ZR imu;
bool ready = false;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  Wire.setClock(100000);
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(25000, true);
#endif
  ready = imu.begin(Wire); // otomatik adres, 6 eksen, 104 Hz
  if (!ready) Serial.println(IMU_ZR::errorText(imu.lastError()));
}

void loop() {
  if (!ready) { delay(100); return; }
  IMU_ZR::ImuSample s;
  if (imu.readImu(s)) {
    // s.acceleration: x/y/z, m/s²
    // s.angularRate: x/y/z, rad/s
    // s.temperature: °C
    // s.timestampUs: host okuma bitiş zamanı
  } else if (imu.lastError() != IMU_ZR::Error::NotReady) {
    Serial.println(IMU_ZR::errorText(imu.lastError()));
  }
}
```

Başlangıç imzası:

```cpp
bool begin(TwoWire &wire = Wire, uint8_t address = 0,
           bool enableMagnetometer = false,
           IMU_ZR::DataRate rate = IMU_ZR::DataRate::Hz104);
```

- Adres `0`: 0x6A/0x6B adreslerinde kimlik denetimiyle otomatik seçim. Belirli adres verirseniz başka adrese geçilmez.
- `Wire.begin()` ve bus hızını kullanıcı ayarlar; özel SDA/SCL pinleri kullanılan kartlarda seçim burada yapılır.
- `address()`: seçilen adres; başlatılmamışsa 0.
- `dataRateHz()` / `samplePeriodUs()`: ayarlanan nominal sensör hızı/periyodu; başlatılmamışsa 0.
- `readImu(s)`: yeni ivme ve gyro hazırsa true. `NotReady` normal bekleme durumudur; başarısız okumada `s` değiştirilmez.
- Aralıklar ±4 g ve ±500 °/s. BDU ve register adres artırma açıktır.
- `lastError()` / `errorText()`: hata ayrıntısı. I²C hatasında `lastBusAddress()`, `lastBusRegister()`, `lastWireStatus()` kullanılabilir. Bunlar son bus hatasını kaydeder; yeni başarılı begin sırasında temizlenir.
- `begin()` sensörleri yeniden yapılandırır ve başlangıçta yaklaşık 100 ms bekler. Döngüde sürekli çağrılmaz; hız değişikliği için yeniden çağrılabilir.

## Örnekleme hızı

```cpp
imu.begin(Wire, 0, false, IMU_ZR::DataRate::Hz208);
```

| DataRate | Nominal hız | Yaklaşık süre |
|---|---:|---:|
| Hz12_5 | 12,5 Hz | 80 ms |
| Hz26 | 26 Hz | 38,46 ms |
| Hz52 | 52 Hz | 19,23 ms |
| Hz104 | 104 Hz | 9,62 ms |
| Hz208 | 208 Hz | 4,81 ms |
| Hz416 | 416 Hz | 2,40 ms |
| Hz833 | 833 Hz | 1,20 ms |
| Hz1660 | 1,66 kHz | 602 µs |
| Hz3330 | 3,33 kHz | 300 µs |
| Hz6660 | 6,66 kHz | 150 µs |

Bu değerler sensör ODR ayarıdır; Arduino'nun tüm örnekleri kayıpsız okuyacağı anlamına gelmez. Sürücü FIFO kullanmaz: yetişilemezse ara örnekler kaybolur, en son hazır örnek okunur. Sensör toleransı, I²C işlem süresi ve seri yazdırma gerçek hızı etkiler. Zaman damgası sensörün örnekleme anı değildir. Yüksek hızlarda 400 kHz I²C ve ölçüm başına metin yazdırmayan bir döngü gerekir; 6,66 kHz'in Mega/I²C ile kayıpsız aktarımı doğrulanmamıştır.

**SamplingRate** örneği 208 Hz seçer, her hazır örneği okumayı dener ve saniyede bir okunan örnek sayısını, gözlenen hızı, hataları ve en uzun okuma çağrısını raporlar. **ImuOnly** kullanım kolaylığı için 20 ms'de bir çıktı verir; ODR'yi artırmak bu örneğin seri çıktı hızını değiştirmez.

## Manyetometre ve kapsam

MMC5603 desteği isteğe bağlı korunmuştur: `imu.begin(Wire, 0, true)`. **Basic9Axis** ve **Diagnostics** örnekleri bu yolu kullanır. Mevcut kart testlerinde manyetometre NACK verdiği için günlük kullanımda **ImuOnly** seçin. Pass-through için doğru kart bağlantısı SCx → SCL ve SDx → SDA olmalıdır. Manyetometre başarısız olduğunda `begin(..., true)` false döner; `imuInitialized()` true ise altı eksen yine okunabilir.

`startMagMeasurement()` + `readMag()` asenkron ölçüm; `readMagBlocking()` tek ölçümü bekleyerek okuma sağlar. Manyetik birim µT, sensörün kendi eksenleridir. Sensör bekleme süresi 50 ms ile sınırlıdır; fiziksel bus kilitlenmesi için Wire çekirdeğinin zaman aşımı desteği gerekir.

Kalibrasyon, eksenleri gövde koordinatlarına dönüştürme, FIFO, SPI, kesme ve sensör füzyonu bu sürümde yoktur. Gyro durağan ofseti sıfır varsayılmaz. Kütüphane sensör yapılandırmasını tek başına yönetmelidir; başka sürücüyle register paylaşımı ve ISR/thread içinden eşzamanlı kullanım desteklenmez.

## Doğrulama ve kaynaklar

`python -m unittest discover -s tests -v` gerçek sürücüyü sahte Wire ile derleyip çalıştırır; Windows Visual Studio C++ Build Tools gerekir. Derleme ve donanım sonuçları `VALIDATION.md` içindedir.

- ST LSM6DSOX DS12814 Rev 4, ODR tabloları s.54–55: https://www.st.com/resource/en/datasheet/lsm6dsox.pdf
- ST AN5272: https://www.st.com/resource/en/application_note/an5272-lsm6dsox-alwayson-3d-accelerometer-and-3d-gyroscope-stmicroelectronics.pdf
- MEMSIC MMC5603NJ Rev B: https://www.memsic.com/Public/Uploads/uploadfile/files/20220119/MMC5603NJDatasheetRev.B.pdf

0.1.x'ten değişiklik: `begin()` varsayılanı artık otomatik adres ve altı eksendir; dokuz eksen isteyen kod açıkça `true` vermelidir.


## Yalnızca jiroskop — 0.2.1

`GyroOnly` örneği ivmeölçeri kapatır ve manyetometreyi kullanmaz. Jiroskop 104 Hz, ±500 °/s; seri çıktı yaklaşık 50 Hz, 115200 baud'dur. Çıktı `timestamp_us,gx_dps,gy_dps,gz_dps` biçimindedir; dps derece/saniye demektir. Adres otomatik tespit edilir.

```cpp
imu.beginGyro(Wire); // otomatik adres, yalnız jiroskop
IMU_ZR::GyroSample g;
if (imu.readGyro(g)) {
  // API birimi rad/s: g.angularRate.x, y, z
  // derece/s için 57.2957795 ile çarpın.
}
```

İsteğe bağlı başlangıç: `imu.beginGyro(Wire, 0, IMU_ZR::DataRate::Hz208)`.
Jiroskop modunda `readImu()` çağrısı `WrongMode` döner; `readGyro()` kullanın. `readGyro()` altı eksen modunda da kullanılabilir, ancak aynı veri için `readImu()` ile arka arkaya çağırmak hazır bayraklarını tüketir. Mod değiştirmek için `begin()` veya `beginGyro()` yeniden çağrılır.

Durağan jiroskopta sıfırdan farklı ofset bulunabilir; sürücü otomatik kalibrasyon uygulamaz. Açısal hız, mutlak açı değildir.

## Datasheet6DoF kayıt örneği

Altı eksen ve sıcaklık register'larını ham sayılar olarak okur; başlangıçta kimlik, ODR/aralık ve BDU/IF_INC ayarlarını geri doğrular. 104 Hz sensör ayarıyla her hazır ivme/gyro çiftini okumayı dener. Seri çıktı 115200 baud, CSV alanları `sequence,timestamp_us,ax_raw,ay_raw,az_raw,gx_raw,gy_raw,gz_raw,temp_raw` biçimindedir.

Dönüşümler: ivme raw×0,000122 g; gyro raw×0,0175 °/s; sıcaklık 25+raw/256 °C. Bu örneğin zaman damgası host okuma bitişidir. Kayıt ve rapor masaüstündeki kaynak klasörünün `measurements/six_dof_datasheet` dizininde bulunur.
