#include "IMU_ZR.h"

namespace {
constexpr uint8_t MAG_ADDRESS = 0x30;
constexpr uint8_t FUNC_CFG_ACCESS = 0x01;
constexpr uint8_t WHO_AM_I = 0x0F;
constexpr uint8_t CTRL1_XL = 0x10;
constexpr uint8_t CTRL2_G = 0x11;
constexpr uint8_t CTRL3_C = 0x12;
constexpr uint8_t STATUS_REG = 0x1E;
constexpr uint8_t OUT_TEMP_L = 0x20;
constexpr uint8_t MASTER_CONFIG = 0x14; // sensor-hub bank
constexpr uint8_t MAG_STATUS = 0x18;
constexpr uint8_t MAG_CTRL0 = 0x1B;
constexpr uint8_t MAG_CTRL1 = 0x1C;
constexpr uint8_t MAG_PRODUCT_ID = 0x39;
constexpr uint32_t MAG_TIMEOUT_MS = 50;
constexpr float GYRO_SCALE = 0.0175f * 0.017453292519943295f;

int32_t signed16(const uint8_t *b) {
  const uint16_t u = uint16_t(b[0]) | (uint16_t(b[1]) << 8);
  return (u & 0x8000U) ? int32_t(u) - 65536L : int32_t(u);
}
float magneticAxis(const uint8_t *b, uint8_t axis) {
  const uint32_t u = (uint32_t(b[axis * 2]) << 12) |
                     (uint32_t(b[axis * 2 + 1]) << 4) |
                     (uint32_t(b[6 + axis]) >> 4);
  return (int32_t(u) - 524288L) * (100.0f / 16384.0f);
}
}

bool IMU_ZR::writeReg(uint8_t device, uint8_t reg, uint8_t value) {
  wire_->beginTransmission(device);
  const bool queued = wire_->write(reg) == 1 && wire_->write(value) == 1;
  const uint8_t status = wire_->endTransmission();
  if (!queued || status != 0) {
    busFailure(device, reg, queued ? status : 1);
    return fail(Error::Bus);
  }
  return true;
}

bool IMU_ZR::readRegs(uint8_t device, uint8_t reg, uint8_t *data, uint8_t size) {
  wire_->beginTransmission(device);
  const bool queued = wire_->write(reg) == 1;
  const uint8_t status = wire_->endTransmission(false);
  if (!queued || status != 0) {
    busFailure(device, reg, queued ? status : 1);
    return fail(Error::Bus);
  }
  const size_t received = wire_->requestFrom(device, size);
  if (received != size || wire_->available() < size) {
    busFailure(device, reg, 0);
    while (wire_->available()) wire_->read();
    return fail(Error::ShortRead);
  }
  for (uint8_t i = 0; i < size; ++i) data[i] = uint8_t(wire_->read());
  return true;
}

bool IMU_ZR::begin(TwoWire &wire, uint8_t imuAddress, bool enableMagnetometer, DataRate rate) {
  return initialize(wire, imuAddress, enableMagnetometer, rate, false);
}

bool IMU_ZR::beginGyro(TwoWire &wire, uint8_t imuAddress, DataRate rate) {
  return initialize(wire, imuAddress, false, rate, true);
}

bool IMU_ZR::initialize(TwoWire &wire, uint8_t imuAddress, bool enableMagnetometer,
                        DataRate rate, bool gyroOnly) {
  imuReady_ = magReady_ = magPending_ = false;
  gyroOnly_ = false;
  error_ = Error::None;
  wire_ = &wire;
  busAddress_ = busRegister_ = wireStatus_ = 0;
  if (imuAddress != 0 && imuAddress != 0x6A && imuAddress != 0x6B)
    return fail(Error::InvalidAddress);
  const uint8_t rateCode = static_cast<uint8_t>(rate);
  if (rateCode < 1 || rateCode > 10) return fail(Error::InvalidRate);
  if (imuAddress == 0) {
    for (uint8_t candidate = 0x6A; candidate <= 0x6B; ++candidate) {
      uint8_t id = 0;
      if (writeReg(candidate, FUNC_CFG_ACCESS, 0x00) &&
          readRegs(candidate, WHO_AM_I, &id, 1) && id == 0x6C) {
        imuAddress = candidate;
        break;
      }
    }
    if (imuAddress == 0) return fail(Error::NotFound);
    error_ = Error::None;
    busAddress_ = busRegister_ = wireStatus_ = 0;
  }
  address_ = imuAddress;
  uint8_t value;
  if (!writeReg(address_, FUNC_CFG_ACCESS, 0x00) ||
      !readRegs(address_, WHO_AM_I, &value, 1)) return false;
  if (value != 0x6C) return fail(Error::WrongImuId);
  if (!writeReg(address_, CTRL3_C, 0x01)) return false;
  const uint32_t started = millis();
  do {
    delay(1);
    if (!readRegs(address_, CTRL3_C, &value, 1)) return false;
    if (!(value & 0x01)) break;
    if (uint32_t(millis() - started) >= 100) return fail(Error::Timeout);
  } while (true);
  // BDU and IF_INC: stable little-endian multi-byte reads.
  if (!writeReg(address_, CTRL3_C, 0x44) ||
      !writeReg(address_, CTRL1_XL, gyroOnly ? 0x00 : uint8_t((rateCode << 4) | 0x08)) ||
      !writeReg(address_, CTRL2_G, uint8_t((rateCode << 4) | 0x04))) return false;
  delay(100); // gyro startup settling; does not calibrate bias
  imuReady_ = true;
  gyroOnly_ = gyroOnly;
  rate_ = rate;
  if (enableMagnetometer && (!enablePassThrough() || !initializeMag())) return false;
  error_ = Error::None;
  return true;
}

float IMU_ZR::dataRateHz() const {
  if (!imuReady_) return 0.0f;
  switch (rate_) {
    case DataRate::Hz12_5: return 12.5f;
    case DataRate::Hz26: return 26.0f;
    case DataRate::Hz52: return 52.0f;
    case DataRate::Hz104: return 104.0f;
    case DataRate::Hz208: return 208.0f;
    case DataRate::Hz416: return 416.0f;
    case DataRate::Hz833: return 833.0f;
    case DataRate::Hz1660: return 1660.0f;
    case DataRate::Hz3330: return 3330.0f;
    case DataRate::Hz6660: return 6660.0f;
  }
  return 0.0f;
}

uint32_t IMU_ZR::samplePeriodUs() const {
  const float rate = dataRateHz();
  return rate > 0 ? uint32_t(1000000.0f / rate + 0.5f) : 0;
}

bool IMU_ZR::enablePassThrough() {
  // Called only just after IMU reset: the sensor-hub master is disabled.
  if (!writeReg(address_, FUNC_CFG_ACCESS, 0x40)) return false;
  const bool written = writeReg(address_, MASTER_CONFIG, 0x10);
  const Error saved = error_;
  // Always attempt to return to the user bank, including after a write failure.
  const bool restored = writeReg(address_, FUNC_CFG_ACCESS, 0x00);
  if (!restored) imuReady_ = false; // register bank is unknown until begin() succeeds
  if (!written) return fail(saved);
  if (!restored) return false;
  delay(1);
  return true;
}

bool IMU_ZR::initializeMag() {
  uint8_t value;
  if (!readRegs(MAG_ADDRESS, MAG_PRODUCT_ID, &value, 1)) return false;
  if (value != 0x10) return fail(Error::WrongMagId);
  if (!writeReg(MAG_ADDRESS, MAG_CTRL1, 0x80)) return false; // software reset
  delay(20);
  if (!readRegs(MAG_ADDRESS, MAG_PRODUCT_ID, &value, 1)) return false;
  if (value != 0x10) return fail(Error::WrongMagId);
  if (!writeReg(MAG_ADDRESS, MAG_CTRL1, 0x00) || // bandwidth 00
      !writeReg(MAG_ADDRESS, MAG_CTRL0, 0x08)) return false; // SET
  delay(1);
  if (!writeReg(MAG_ADDRESS, MAG_CTRL0, 0x10)) return false; // RESET
  delay(1);
  if (!writeReg(MAG_ADDRESS, MAG_CTRL0, 0x20)) return false; // Auto_SR_en
  magReady_ = true;
  return true;
}

bool IMU_ZR::readImu(ImuSample &sample) {
  error_ = Error::None;
  if (!imuReady_) return fail(Error::NotInitialized);
  if (gyroOnly_) return fail(Error::WrongMode);
  uint8_t status, b[14];
  if (!readRegs(address_, STATUS_REG, &status, 1)) return false;
  if ((status & 0x03) != 0x03) return fail(Error::NotReady);
  if (!readRegs(address_, OUT_TEMP_L, b, sizeof(b))) return false;
  const float accelerationScale = 0.000122f * 9.80665f;
  ImuSample result;
  result.temperature = 25.0f + signed16(b) / 256.0f;
  result.angularRate = {signed16(b + 2) * GYRO_SCALE, signed16(b + 4) * GYRO_SCALE,
                        signed16(b + 6) * GYRO_SCALE};
  result.acceleration = {signed16(b + 8) * accelerationScale,
                         signed16(b + 10) * accelerationScale,
                         signed16(b + 12) * accelerationScale};
  result.timestampUs = micros();
  sample = result;
  return true;
}

bool IMU_ZR::readGyro(GyroSample &sample) {
  error_ = Error::None;
  if (!imuReady_) return fail(Error::NotInitialized);
  uint8_t status, b[6];
  if (!readRegs(address_, STATUS_REG, &status, 1)) return false;
  if (!(status & 0x02)) return fail(Error::NotReady);
  if (!readRegs(address_, 0x22, b, sizeof(b))) return false;
  GyroSample result;
  result.angularRate = {signed16(b) * GYRO_SCALE, signed16(b + 2) * GYRO_SCALE,
                        signed16(b + 4) * GYRO_SCALE};
  result.timestampUs = micros();
  sample = result;
  return true;
}

bool IMU_ZR::startMagMeasurement() {
  error_ = Error::None;
  if (!magReady_) return fail(Error::NotInitialized);
  if (magPending_) {
    if (uint32_t(millis() - magStartedMs_) < MAG_TIMEOUT_MS) return fail(Error::Busy);
    magPending_ = false;
  }
  // Discard any previously completed result (data read clears Meas_M_Done).
  uint8_t discard[9];
  if (!readRegs(MAG_ADDRESS, 0x00, discard, sizeof(discard)) ||
      !writeReg(MAG_ADDRESS, MAG_CTRL0, 0x21)) return false;
  magStartedMs_ = millis();
  magPending_ = true;
  return true;
}

bool IMU_ZR::readMag(MagSample &sample) {
  error_ = Error::None;
  if (!magReady_) return fail(Error::NotInitialized);
  if (!magPending_) return fail(Error::NotReady);
  uint8_t status, b[9];
  if (!readRegs(MAG_ADDRESS, MAG_STATUS, &status, 1)) return false;
  if (!(status & 0x40)) {
    if (uint32_t(millis() - magStartedMs_) >= MAG_TIMEOUT_MS) {
      magPending_ = false;
      return fail(Error::Timeout);
    }
    return fail(Error::NotReady);
  }
  if (!readRegs(MAG_ADDRESS, 0x00, b, sizeof(b))) return false;
  MagSample result;
  result.magneticField = {magneticAxis(b, 0), magneticAxis(b, 1), magneticAxis(b, 2)};
  result.timestampUs = micros();
  magPending_ = false;
  sample = result;
  return true;
}

bool IMU_ZR::readMagBlocking(MagSample &sample) {
  if (!startMagMeasurement()) return false;
  while (!readMag(sample)) {
    if (error_ != Error::NotReady) return false;
    delay(1);
  }
  return true;
}

const char *IMU_ZR::errorText(Error error) {
  switch (error) {
    case Error::None: return "OK";
    case Error::InvalidAddress: return "Address must be 0 (auto), 0x6A or 0x6B";
    case Error::NotFound: return "LSM6DSOX not found at 0x6A/0x6B";
    case Error::InvalidRate: return "Unsupported IMU data rate";
    case Error::WrongMode: return "Accelerometer is off; use readGyro()";
    case Error::Bus: return "I2C transmission failed";
    case Error::ShortRead: return "Incomplete I2C read";
    case Error::WrongImuId: return "LSM6DSOX WHO_AM_I mismatch";
    case Error::WrongMagId: return "MMC5603 product ID mismatch";
    case Error::NotInitialized: return "Sensor not initialized";
    case Error::NotReady: return "No fresh data yet";
    case Error::Busy: return "Magnetic measurement already pending";
    case Error::Timeout: return "Sensor conversion/reset timed out";
  }
  return "Unknown error";
}
