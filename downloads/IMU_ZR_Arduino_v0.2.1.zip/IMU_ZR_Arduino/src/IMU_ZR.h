#pragma once
#include <Arduino.h>
#include <Wire.h>

class IMU_ZR {
public:
  enum class Error : uint8_t {
    None, InvalidAddress, Bus, ShortRead, WrongImuId, WrongMagId,
    NotInitialized, NotReady, Busy, Timeout, NotFound, InvalidRate, WrongMode
  };
  enum class DataRate : uint8_t {
    Hz12_5 = 1, Hz26, Hz52, Hz104, Hz208, Hz416, Hz833,
    Hz1660, Hz3330, Hz6660
  };
  struct Vector { float x, y, z; };
  struct ImuSample {
    Vector acceleration;  // m/s^2, sensor-native axes
    Vector angularRate;   // rad/s, sensor-native axes
    float temperature;    // degrees C, LSM6DSOX die temperature
    uint32_t timestampUs; // host read completion time, not sensor sample time
  };
  struct MagSample {
    Vector magneticField; // microtesla, MMC5603-native axes
    uint32_t timestampUs;
  };
  struct GyroSample {
    Vector angularRate;   // rad/s, sensor-native axes
    uint32_t timestampUs; // host read completion time
  };

  // Call wire.begin() first. This driver owns the sensors' configuration.
  // Defaults: 104 Hz, +/-4 g, +/-500 dps; magnetic single shots with auto SET/RESET.
  // Address 0 detects 0x6A/0x6B. Magnetometer is OFF by default.
  // Rate selects both sensors' nominal ODR, not the host/serial output rate.
  bool begin(TwoWire &wire = Wire, uint8_t imuAddress = 0,
             bool enableMagnetometer = false, DataRate rate = DataRate::Hz104);
  // Powers down the accelerometer; never initializes the magnetometer.
  bool beginGyro(TwoWire &wire = Wire, uint8_t imuAddress = 0,
                 DataRate rate = DataRate::Hz104);
  uint8_t address() const { return imuReady_ ? address_ : 0; }
  float dataRateHz() const;
  uint32_t samplePeriodUs() const;
  bool readImu(ImuSample &sample);
  bool readGyro(GyroSample &sample);
  bool startMagMeasurement();
  // Returns NotReady while converting; leaves sample untouched on any failure.
  bool readMag(MagSample &sample);
  bool readMagBlocking(MagSample &sample);
  bool imuInitialized() const { return imuReady_; }
  bool magInitialized() const { return magReady_; }
  Error lastError() const { return error_; }
  uint8_t lastBusAddress() const { return busAddress_; }
  uint8_t lastBusRegister() const { return busRegister_; }
  uint8_t lastWireStatus() const { return wireStatus_; }
  static const char *errorText(Error error);

private:
  TwoWire *wire_ = nullptr;
  uint8_t address_ = 0x6A;
  DataRate rate_ = DataRate::Hz104;
  bool imuReady_ = false, magReady_ = false, magPending_ = false;
  bool gyroOnly_ = false;
  uint32_t magStartedMs_ = 0;
  Error error_ = Error::None;
  uint8_t busAddress_ = 0, busRegister_ = 0, wireStatus_ = 0;
  void busFailure(uint8_t device, uint8_t reg, uint8_t status) {
    busAddress_ = device; busRegister_ = reg; wireStatus_ = status;
  }
  bool fail(Error error) { error_ = error; return false; }
  bool writeReg(uint8_t device, uint8_t reg, uint8_t value);
  bool readRegs(uint8_t device, uint8_t reg, uint8_t *data, uint8_t size);
  bool enablePassThrough();
  bool initializeMag();
  bool initialize(TwoWire &wire, uint8_t imuAddress, bool enableMagnetometer,
                  DataRate rate, bool gyroOnly);
};
